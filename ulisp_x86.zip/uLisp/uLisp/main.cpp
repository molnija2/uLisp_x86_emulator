#include <QCoreApplication>


void loop();
void setup();

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    setup();

    loop();

    return a.exec();
    //return 0;
}
