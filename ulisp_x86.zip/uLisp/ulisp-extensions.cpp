#include <unistd.h>
#include <stdlib.h>


#include "ulisp.h"
#include "graph_tcp.h"

//extern object *tee;

/*
 User Extensions
*/



// Definitions

unsigned long millis() { return 0; };

object *fn_now (object *args, object *env) {
  (void) env;
  static unsigned long Offset;
  unsigned long now = millis()/1000;
  int nargs = listlength(args);

  // Set time
  if (nargs == 3) {
    Offset = (unsigned long)((checkinteger(first(args))*60 + checkinteger(second(args)))*60
      + checkinteger(third(args)) - now);
  } else if (nargs > 0) error2(PSTR("wrong number of arguments"));
  
  // Return time
  unsigned long secs = Offset + now;
  object *seconds = number(secs%60);
  object *minutes = number((secs/60)%60);
  object *hours = number((secs/3600)%24);
  return cons(hours, cons(minutes, cons(seconds, NULL)));
}



object *fn_touch_press (object *args, object *env) {
  (void) env;
#ifdef touchscreen_support

  return  MouseStateButtons() ? tee : nil;
#else
  return nil ;
#endif
}

object *fn_touch_x (object *args, object *env) {
  (void) env;
#ifdef  touchscreen_support
  return number(MouseStateX());
#else
  return nil ;
#endif
}

object *fn_touch_y (object *args, object *env) {
  (void) env;
#ifdef touchscreen_support


    return number(MouseStateY());
#else
  return nil ;
#endif
}

void PrintToucscreenParameters ()
{
#ifdef touchscreen_support

#endif
}

object *fn_touch_printcal (object *args, object *env)
{
  (void) env;

  PrintToucscreenParameters() ;

  return tee ;
}

object *fn_touch_setcal(object *args, object *env)
{
  (void) env;

#ifdef touchscreen_support
    return tee ;

#endif


return nil ;
}

void drawCalibrationPrompt()
{
  //tft.setTextColor(TFT_RED, TFT_BLACK) ;
  //tft.drawString("Touch calibration", 100, 40) ;
  //tft.setTextColor(TFT_GREEN, TFT_BLACK) ;
  //tft.drawString("Press this point", 100, 50) ;
}


void drawCalibrationTestPrompt()
{
  //tft.setTextColor(TFT_BLUE, TFT_BLACK) ;
  //tft.drawString("Test touch calibration", 100, 40) ;
  //tft.setTextColor(TFT_GREEN, TFT_BLACK) ;
  //tft.drawString("Press this point", 100, 50) ;
}


void drawCalibrationCross(uint16_t x, uint16_t y, uint16_t color)
{
  //tft.drawLine(x-10, y, x+10, y, color) ;
  //tft.drawLine(x, y-10, x, y+10, color) ;
}






object *fn_touch_calibrate(object *args, object *env)
{
  (void) env;

#ifdef touchscreen_support


  return tee;
#else
  return nil ;
#endif
}



// Symbol names
char stringnow[]  = "now";
char stringtouch_press[] = "touch-press";
char stringtouch_x[] = "touch-x";
char stringtouch_y[] = "touch-y";
char stringtouch_calibrate[] = "touch-calibrate";
char stringtouch_setcal[] = "touch-setcal";
char stringtouch_printcal[] = "touch-printcal";
char stringquit[] = "quit";


// Documentation strings
char docnow[]  = "(now [hh mm ss])\n"
"Sets the current time, or with no arguments returns the current time\n"
"as a list of three integers (hh mm ss).";

char doctouch_press[] = "(touch-press)\n"
"Returns true if touchscreen is pressed and false otherwise.";
char doctouch_x[] = "(touch-x)\n"
"Returns pressed touchscreen x-coordinate.";
char doctouch_y[] = "(touch-y)\n"
"Returns pressed touchscreen y-coordinate.";
char doctouch_calibrate[] = "(touch-calibrate)\n"
"Runs touchscreen calibration.";
char doctouch_setcal[] = "(touch-setcal minx maxx miny maxy\n      hres vres axisswap xflip yflip)\n"
"Set touchscreen calibration parameters.";
char doctouch_printcal[] = "(touch-printcal)\n"
"Print touchscreen calibration parameters.";

char docquit[] = "(quit)\n"
"Exit from Lisp.";


// Symbol lookup table
tbl_entry_t lookup_table2[]  = {
    { stringnow, fn_now, 0203, docnow },
    { stringtouch_press, fn_touch_press, 0200, doctouch_press },
    { stringtouch_x, fn_touch_x, 0200, doctouch_x },
    { stringtouch_y, fn_touch_y, 0200, doctouch_y },
    { stringtouch_calibrate, fn_touch_calibrate, 0200, doctouch_calibrate },
    { stringtouch_setcal, fn_touch_setcal, 0217, doctouch_setcal },
    { stringtouch_printcal, fn_touch_printcal, 0200, doctouch_printcal },

    { stringquit, fn_quit, 0203, docquit },
};

// Table cross-reference functions

tbl_entry_t *tables[] = {lookup_table, lookup_table2};
unsigned int tablesizes[] = { arraysize(lookup_table), arraysize(lookup_table2) };

tbl_entry_t *table (int n) {
  return tables[n];
}

unsigned int tablesize (int n) {
  return tablesizes[n];
}
